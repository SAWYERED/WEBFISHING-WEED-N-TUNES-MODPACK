![image](https://github.com/user-attachments/assets/24a564ae-0ce1-4615-9d29-20cd31ebd636)


## Weed+Tunesmetics  
Weed+Tunes Dedicated C- erm... Server Cosmetics! Adds Titles and Colors, + Alien Cosmetics  

You can also find this mod at it's [Home Page](https://github.com/SAWYERED/WEBFISHING-WEED-N-TUNES-MODPACK)  
  
<details>
<summary>New Colors!</summary>  

  
| Name | Hex | Type |  
| --- | --- | --- |  
| <span style='color: #7298DA ;'>**Discord Blurple (original)** | #7298DA  | Primay & Secondary  |  
| <span style='color: #5865F2 ;'>**Discord Blurple (new)** | #5865F2  | Primay & Secondary  |  
| <span style='color: #6577E6;'>**Discord Blurple (hybrid)** | #6577E6 | Primay & Secondary  |  
| <span style='color: #00FF00;'>**Razer Green** | #00FF00 | Primay & Secondary  |  
| <span style='color: #FF1B2D ;'>**Opera Red** | #FF1B2D  | Primay & Secondary  |  
| <span style='color: #CCFF00 ;'>**Chartreuse** | #CCFF00  | Primay & Secondary  |  
| <span style='color: #9FC54E;'>**Catfish Green** | #9FC54E | Primay & Secondary  |  
| <span style='color: #437D4D;'>**Gleeb Green** | #437D4D | Primay & Secondary  |  


</details>  

  
### Credits
This mod was created by SAWYERED using [Hatchery](https://github.com/coolbot100s/Hatchery) v1.3.2
