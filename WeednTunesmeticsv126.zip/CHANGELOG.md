## Initial Release 🥳  
Added Several Titles, Fixed some Titles and also added Colors. Hatchery driving me insane hahahahah